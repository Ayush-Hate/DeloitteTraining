package patient.dao;

import java.util.*;
import org.hibernate.*;
import org.hibernate.boot.*;
import org.hibernate.boot.registry.*;
import patient.model.*;

public class MedicinesDAO {

	private StandardServiceRegistry registry;
	private SessionFactory factory;
	
	public SessionFactory getSessionFactory() {
		if (factory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			factory = metadata.getSessionFactoryBuilder().build();
		}
		return factory;
	}

	public void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}
	
	//create
	public void create(Medicines m) {
		try(Session session = getSessionFactory().openSession())
		{
			session.getTransaction().begin();
			session.save(m);
			session.getTransaction().commit();
		}
	}
	//read
	public List<Medicines> read() {
		
		List<Medicines> m = new ArrayList<Medicines>();
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			m = session.createQuery("FROM Medicines m", Medicines.class).getResultList();
		}
		return m;
	}
	//update
	public void update(Medicines obj) {
		try(Session session = getSessionFactory().openSession())
		{
			session.getTransaction().begin();
			session.update(obj);
			session.getTransaction().commit();
		}
	}
	//delete
	public void delete(int id) {
		try(Session session = getSessionFactory().openSession())
		{
			session.getTransaction().begin();
			Medicines obj = (Medicines) session.load(Medicines.class, id);
			session.delete(obj);
			session.getTransaction().commit();
		}
	}

}
