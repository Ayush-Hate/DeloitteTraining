package patient.dao;

import java.util.*;
import org.hibernate.*;
import org.hibernate.boot.*;
import org.hibernate.boot.registry.*;
import patient.model.*;

public class PrescriptionsDAO {
	
	private StandardServiceRegistry registry;
	private SessionFactory factory;
	
	public SessionFactory getSessionFactory() {
		if (factory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			factory = metadata.getSessionFactoryBuilder().build();
		}
		return factory;
	}

	public void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}
	
	//create
	public void create(Prescriptions p) {
		try(Session session = getSessionFactory().openSession())
		{
			session.getTransaction().begin();
			session.save(p);
			session.getTransaction().commit();
		}
	}
	//read
	public List<Prescriptions> read() {
		
		List<Prescriptions> p = new ArrayList<Prescriptions>();
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			p = session.createQuery("FROM Prescriptions p", Prescriptions.class).getResultList();
		}
		return p;
	}
	//update
	public void update(Prescriptions obj) {
		try(Session session = getSessionFactory().openSession())
		{
			session.getTransaction().begin();
			session.update(obj);
			session.getTransaction().commit();
		}
	}
	//delete
	public void delete(int id) {
		try(Session session = getSessionFactory().openSession())
		{
			session.getTransaction().begin();
			Prescriptions obj = (Prescriptions) session.load(Prescriptions.class, id);
			session.delete(obj);
			session.getTransaction().commit();
		}
	}

}
