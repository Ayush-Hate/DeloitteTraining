package patient.dao;

import java.util.*;
import org.hibernate.*;
import org.hibernate.boot.*;
import org.hibernate.boot.registry.*;
import patient.model.*;

public class PatientsDAO {
	private StandardServiceRegistry registry;
	private SessionFactory factory;
	
	public SessionFactory getSessionFactory() {
		if (factory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			factory = metadata.getSessionFactoryBuilder().build();
		}
		return factory;
	}

	public void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}
	
	//create
	public void create(Patients p) {
		try(Session session = getSessionFactory().openSession())
		{
			session.getTransaction().begin();
			session.save(p);
			session.getTransaction().commit();
		}
	}
	//read
	public List<Patients> read() {
		
		List<Patients> p = new ArrayList<Patients>();
		try (Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			p = session.createQuery("FROM Patients p", Patients.class).getResultList();
		}
		return p;
	}
	//update
	public void update(Patients obj) {
		try(Session session = getSessionFactory().openSession())
		{
			session.getTransaction().begin();
			session.update(obj);
			session.getTransaction().commit();
		}
	}
	//delete
	public void delete(int id) {
		try(Session session = getSessionFactory().openSession())
		{
			session.getTransaction().begin();
			Patients obj = (Patients) session.load(Patients.class, id);
			session.delete(obj);
			session.getTransaction().commit();
		}
	}

}
