package patient.model;

import javax.persistence.*;

@Entity
@Table(name="MEDICINE")
public class Medicines {

	@Id
	@Column(name="MEDICINE_ID")
	private int medicineId;
	
	@Column(name="MEDICINE_NAME")
	private String medicineName;
	
	public Medicines() {
	}

	public Medicines(int medicineId, String medicineName) {
		this.medicineId = medicineId;
		this.medicineName = medicineName;
	}

	public int getMedicineId() {
		return medicineId;
	}

	public void setMedicineId(int medicineId) {
		this.medicineId = medicineId;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}


}
