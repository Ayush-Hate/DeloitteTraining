package patient.model;

import javax.persistence.*;

@Entity
@Table(name="PRESCRIPTION_2")
public class Prescriptions {

	@Id
	@Column(name="PRESCRIPTION_ID")
	private int prescriptionId;
	
	@OneToOne
	private Medicines medicine;
	
	@ManyToOne(targetEntity=Patients.class)
	private Patients patient;
	
	public Prescriptions() {
	}

	public Prescriptions(int prescriptionId) {
		this.prescriptionId = prescriptionId;
	}

	public int getPrescriptionId() {
		return prescriptionId;
	}

	public void setPrescriptionId(int prescriptionId) {
		this.prescriptionId = prescriptionId;
	}

	public Medicines getMedicine() {
		return medicine;
	}

	public void setMedicine(Medicines medicine) {
		this.medicine = medicine;
	}

	public Patients getPatient() {
		return patient;
	}

	public void setPatient(Patients patient) {
		this.patient = patient;
	}
	
	
}
