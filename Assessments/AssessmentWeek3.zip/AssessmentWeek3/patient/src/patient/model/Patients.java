package patient.model;

import java.util.*;
import javax.persistence.*;

@Entity
@Table(name="PATIENTS_2")
public class Patients {
	
	@Id
	@Column(name="PATIENT_ID")
	private int patientId;
	
	@Column(name="PATIENT_NAME")
	private String patientName;
	
	@Column(name="PATIENT_EMAIL")
	private String patientEmail;
	
	public Patients() {
	}

	public Patients(int patientId, String patientName, String patientEmail) {
		this.patientId = patientId;
		this.patientName = patientName;
		this.patientEmail = patientEmail;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientEmail() {
		return patientEmail;
	}

	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}	
	
}
