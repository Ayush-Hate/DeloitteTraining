package patient.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import patient.dao.*;
import patient.model.*;
/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/PrescriptionControllerServlet")
public class PrescriptionControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private PrescriptionsDAO prescriptionsDAO;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrescriptionControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		prescriptionsDAO = new PrescriptionsDAO();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("choice");
		
		if(action.equals("create"))
		{
			int prescriptionId = Integer.parseInt(request.getParameter("prescriptionId").trim());
			Prescriptions newPrescription = new Prescriptions(prescriptionId);
			Patients patient = new Patients(); //GET CURRENT PATIENTS AND MEDICINE OBJECT FROM GET PARAM
			Medicines medicine = new Medicines(); // request.getAttribute("medicineObj");
			newPrescription.setPatient(patient);
			newPrescription.setMedicine(medicine);
	        prescriptionsDAO.create(newPrescription);
	        response.sendRedirect("/index.jsp");//SEND BACK TO HOME PAGE
		}
		else if(action.equals("read"))
		{
			List<Prescriptions> prescriptionList = prescriptionsDAO.read();
			RequestDispatcher dispatch = request.getRequestDispatcher("prescriptionsList.jsp");
			request.setAttribute("prescriptionList", prescriptionList);
			dispatch.forward(request, response);
		}
		else if(action.equals("update"))
		{
			int prescriptionId = Integer.parseInt(request.getParameter("prescriptionId").trim());
			Prescriptions newPrescription = new Prescriptions(prescriptionId);
			Patients patient = new Patients(); //GET CURRENT PATIENTS AND MEDICINE OBJECT FROM GET PARAM
			Medicines medicine = new Medicines(); // request.getAttribute("medicineObj");
			newPrescription.setPatient(patient);
			newPrescription.setMedicine(medicine);
	        prescriptionsDAO.update(newPrescription);
	        response.sendRedirect("/index.jsp");
		}
		else if(action.equals("delete"))
		{
			int prescriptionId = Integer.parseInt(request.getParameter("prescriptionId").trim());
			prescriptionsDAO.delete(prescriptionId);
	        response.sendRedirect("/index.jsp");
		}

}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
