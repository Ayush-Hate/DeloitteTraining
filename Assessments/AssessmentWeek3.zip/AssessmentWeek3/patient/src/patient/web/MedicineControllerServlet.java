package patient.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import patient.dao.*;
import patient.model.*;
/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/MedicineControllerServlet")
public class MedicineControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private MedicinesDAO medicinesDAO;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MedicineControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		medicinesDAO = new MedicinesDAO();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("choice");
		
		if(action.equals("create"))
		{
			int medicineId = Integer.parseInt(request.getParameter("medicineId").trim());
			String medicineName = request.getParameter("medicineName");
	        Medicines newMedicine = new Medicines(medicineId, medicineName);
	        medicinesDAO.create(newMedicine);
	        response.sendRedirect("/index.jsp");//SEND BACK TO HOME PAGE
		}
		else if(action.equals("read"))
		{
			List<Medicines> medicineList = medicinesDAO.read();
			RequestDispatcher dispatch = request.getRequestDispatcher("medicinesList.jsp");
			request.setAttribute("medicinesList", medicineList);
			dispatch.forward(request, response);
		}
		else if(action.equals("update"))
		{
			int medicineId = Integer.parseInt(request.getParameter("medicineId").trim());
			String medicineName = request.getParameter("medicineName");
	        Medicines newMedicine = new Medicines(medicineId, medicineName);
	        medicinesDAO.update(newMedicine);
	        response.sendRedirect("/index.jsp");
		}
		else if(action.equals("delete"))
		{
			int medicineId = Integer.parseInt(request.getParameter("medicineId").trim());
			medicinesDAO.delete(medicineId);
	        response.sendRedirect("/index.jsp");
		}

}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
