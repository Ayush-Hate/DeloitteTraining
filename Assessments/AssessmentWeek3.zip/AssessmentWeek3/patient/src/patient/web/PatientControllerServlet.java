package patient.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import patient.dao.*;
import patient.model.*;
/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/PatientControllerServlet")
public class PatientControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private PatientsDAO patientsDAO;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		patientsDAO = new PatientsDAO();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("choice");
		
		if(action.equals("create"))
		{
			int patientId = Integer.parseInt(request.getParameter("patientId").trim());
			String patientName = request.getParameter("patientName");
	        String patientEmail = request.getParameter("patientEmail");
	        Patients newPatient = new Patients(patientId, patientName, patientEmail);
	        patientsDAO.create(newPatient);
	        response.sendRedirect("/index.jsp");//SEND BACK TO HOME PAGE
		}
		else if(action.equals("read"))
		{
			List<Patients> patientList = patientsDAO.read();
			RequestDispatcher dispatch = request.getRequestDispatcher("patientsList.jsp");
			request.setAttribute("patientList", patientList);
			dispatch.forward(request, response);
		}
		else if(action.equals("update"))
		{
			int patientId = Integer.parseInt(request.getParameter("patientId").trim());
			String patientName = request.getParameter("patientName");
	        String patientEmail = request.getParameter("patientEmail");
	        Patients newPatient = new Patients(patientId, patientName, patientEmail);
	        patientsDAO.update(newPatient);
	        response.sendRedirect("/index.jsp");
		}
		else if(action.equals("delete"))
		{
			int patientId = Integer.parseInt(request.getParameter("patientId"));
			patientsDAO.delete(patientId);
	        response.sendRedirect("/index.jsp");
		}

}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
